# aExpress
Ecommerce Application Tutorial (Source) - Mian Speaks

# How to setup Admin Panel

###### Step 1: Download Source Code
https://github.com/mianasadali1/aExpress/blob/master/Web%20Source%20Code/SourceCode.zip

###### Step 2: Upload Code & Database

###### Step 3: Change database credientals in services/conf.php file

###### All Done.

# How to connect your panel with app

###### Step 1: In your android studio open Constants.java

###### Step 2: Change BASE_URL with your URL

# Used Libraries

Material Search Bar:
https://github.com/mancj/MaterialSearchBar

Rounded Image View:
https://github.com/vinc3m1/RoundedImageView

Carousel:
https://github.com/ImaginativeShohag/Why-Not-Image-Carousel

Android Volley:
https://google.github.io/volley

Tiny Cart:
https://github.com/hishd/TinyCart

Advanced Webview:
https://github.com/delight-im/Android-AdvancedWebView

# Free SVG Icons
https://www.svgrepo.com
